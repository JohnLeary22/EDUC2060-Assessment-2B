# EDUC2060 — Component 3: Multimodal Presentation

We're going to develop the full 4–5-minute presentation script through the same four-stage rubric methodology used for Components 1 and 2.

The presentation will use your existing website as its visual component. You'll narrate the evaluation, demonstrate the changes and explain your teaching decisions while moving through the website.

The four stages will be preserved separately so the Component 3 tab can show how the script developed.

## 1. The rubric we're working against

| Step | Rubric band                               | What we need to demonstrate                                                                                                                      |
| ---- | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1    | Multistructural — C                       | Clearly present the key elements using appropriate multimodal features.                                                                          |
| 2    | Relational — B / Unistructural — D        | Improve synthesis, organisation and purposeful use of visuals; avoid basic communication with limited multimodal value.                          |
| 3    | Extended Abstract — A / Prestructural — F | Develop an engaging, polished and persuasive presentation that critically justifies decisions and demonstrates reflective professional practice. |
| 4    | Whole criterion review                    | Evaluate the final script against the full rubric, especially the A-band wording.                                                                |

The assessment instructions specifically require us to evaluate the unit plan, justify the three changes with close reference to course readings and independent research, and outline the proposed assessment task.

Each script below is a complete recording draft, not merely an outline.

## Step 1 — Initial presentation script (C band)

Approximately 500 words · Suitable initial draft · Around 4 minutes at a measured speaking pace

# Step 1 — Initial Presentation Script

I selected the NESA Stage 5 Year 9 Commerce unit, *The Business Environment*. My aim was not to replace a generally sound program, but to identify three places where students could make more informed business decisions.

I began with a SWOT analysis of the written unit. Its strengths include authentic case studies, varied teaching strategies, ethical issues, and a local-business site study. However, some group activities leave responsibilities unclear, some tasks can be completed by describing rather than evaluating, and the unit does not develop a dedicated inquiry into AI adoption. These observations concern the written plan, not evidence that a teacher or class has failed.

My first change is **Replacement**. The unit already explains recruitment and asks students to investigate recruitment mistakes. I kept that teaching but replaced the optional role-play and script with a hiring-panel simulation. Students receive a job description, selection criteria and candidate profiles. They first make individual rankings and then discuss their recommendations in assigned roles. When business circumstances change, the panel must reconsider its choice. Students finish with an individual justification explaining how their selection affects performance. This gives the activity a more direct decision-making purpose.

My second change is **Expansion**. The local-business visit is already one of the unit's strongest experiences. Students observe a business, speak with an owner and prepare a report. Rather than creating another excursion, I strengthened the inquiry within that report. Students develop a focused question, distinguish their observations from an owner's claims, compare evidence and recommend an achievable improvement. They respond to feedback by revising part of their recommendation. Students who cannot attend receive comparable sources. The aim is to build on an authentic learning opportunity while making the reasoning more explicit.

My third change is **Insertion**. The original unit lists contemporary issues, including cybersecurity and influencer entrepreneurship, but does not explore whether a small business should adopt AI. I added a focused investigation in its existing current-issues allocation. Students compare options to adopt, trial or defer an AI tool, considering costs, customers and workers. They use dated business data and make a recommendation rather than assuming that new technology is automatically beneficial.

These choices are informed by the Week 11 course materials on combining explicit teaching with inquiry, Dunn's 2025 reading on questioning and evaluating evidence, and Australian Bureau of Statistics data on AI use. The research supports our approach; it does not prove the activities will succeed before classroom implementation.

To assess the revised learning, I propose an individual business advisory brief for a hypothetical café. Students diagnose a performance problem, recommend a staff member, and evaluate a feasible improvement within a budget. Four selected Commerce outcomes cover business knowledge, decision factors, problem solving and communication. A common evidence pack allows all students to work from the same information.

Overall, the three changes move from recruiting people, to investigating an existing business, to judging a contemporary investment. My intention is to retain the unit's strengths while asking students to support business decisions with evidence.

### What Step 1 achieves

The script covers the assessment's required content and can be presented using the existing website. However, its research references are brief, its reasoning is mostly descriptive, and the structure does not yet fully explain why the changes are preferable to the original approaches.

That's what we'll develop in Step 2.

## Step 2 — Improved presentation script (B and D bands)

Green — B-band improvements

Yellow — D-band safeguards

Grey — general refinements

The important changes are stronger connections between evidence, decisions and assessment, as well as clearer links between the website's visual features and what you're explaining.

Approximately 535 words · Around 4–4½ minutes

# Step 2 — Revised Presentation Script

I selected the NESA Stage 5 Year 9 Commerce unit, *The Business Environment*. My aim was not to replace a generally sound program, but to identify three places where students could make more informed business decisions—and to show why those changes better serve the existing learning goals.

I began with a SWOT analysis of the written unit. Its strengths include authentic case studies, varied teaching strategies, ethical issues, and a local-business site study. However, some group activities leave responsibilities unclear, some tasks can be completed by describing rather than evaluating, and the unit does not develop a dedicated inquiry into AI adoption. These are design observations, not claims about classroom outcomes. On screen, I have linked each critique to the precise original passage rather than labelling the entire program deficient.

My first change is **Replacement**. The unit already explains recruitment and asks students to investigate recruitment mistakes. I kept that teaching but replaced the optional role-play and script with a hiring-panel simulation. Students receive a job description, selection criteria and candidate profiles. They first make individual rankings and then discuss their recommendations in assigned roles. When business circumstances change, the panel must reconsider its choice. Each student then justifies a recommendation and its effect on business performance. This makes the original evaluation goal more visible: students must compare alternatives, not just act out an error. The modelled matrix also connects teacher instruction to collaborative inquiry.

My second change is **Expansion**. The local-business visit is already one of the unit's strongest experiences. Students observe a business, speak with an owner and prepare a report, with feedback and alternatives already provided. I strengthened the inquiry within that same report. Students develop a focused question, separate observations from an owner's claims, compare sources and recommend an achievable improvement. They revise one claim following feedback. Students who cannot attend use a comparable evidence pack. Dunn's 2025 course reading describes inquiry as questioning, collecting and evaluating evidence after explicit teaching. This change applies those stages without adding a second assignment.

My third change is **Insertion**. The original unit lists contemporary issues, including cybersecurity and influencer entrepreneurship, but does not explore whether a small business should adopt AI. I added a focused investigation within the existing current-issues allocation. Students weigh adopting, trialling or deferring a tool against costs, customers and staffing. The ABS reported that 12 per cent of Australian businesses used AI in 2024–25. That figure shows uptake, not whether adoption succeeds. Students must therefore explain what evidence would actually justify their recommendation.

The Week 10 module emphasises alignment between curriculum, classroom learning, learners and assessment. My proposed assessment follows that logic: students prepare a 600-to-750-word advisory brief to a fictional café owner. Using the same case pack, they diagnose business performance, compare recruitment options and recommend a feasible improvement within a fixed budget. Selected outcomes assess business concepts, decision factors, solutions and communication. No compulsory site visit or AI software is needed.

The design principle connecting these changes is consistent: make students' reasoning visible while retaining the authentic tasks the NESA program already offers. I would judge their effectiveness through the quality of evidence and decisions students produce, not through how busy the activities look.

### The discernible Step 2 revisions

| Rubric influence | Revision                                                                                | Why it matters                                   |
| ---------------- | --------------------------------------------------------------------------------------- | ------------------------------------------------ |
| B — Green        | Explain that the recruitment change makes evaluation visible, not merely participation. | Connects a change to its educational purpose.    |
| B — Green        | Reference Dunn directly when explaining the site study.                                 | Synthesises research and a design decision.      |
| B — Green        | Explain what the ABS statistic does and does not establish.                             | Demonstrates critical use of evidence.           |
| B — Green        | Connect the assessment to Week 10's emphasis on alignment.                              | Shows how the unit changes lead into assessment. |
| D — Yellow       | Acknowledge what the original unit already does well.                                   | Avoids vague or unjustified criticism.           |
| D — Yellow       | Specify the assessment audience, length and resources.                                  | Prevents unclear communication.                  |
| Grey             | Tighten transitions and make the three changes follow the same explanatory pattern.     | Improves narrative flow.                         |

This is the version informed by the adjacent bands: more purposeful and better connected, without changing the whole presentation.

## Step 3 — Polished presentation script (A and F bands)

Blue — A-band refinements

Red — F-band safeguards

Grey — general refinements

This is the version I would use as the provisional final recording script.

The most significant change is the opening: rather than beginning with what the assignment required, it introduces a genuine business problem. That gives the presentation a central argument linking all three decisions.

The other important addition is your reflection on the Week 10 rubric workshop. This directly addresses the A-band requirement for reflective professional practice.

Approximately 570 words · Around 4¼–4¾ minutes with deliberate transitions

# Step 3 — Final Presentation Script

A café needs to hire a supervisor, improve customer service and decide whether an AI tool is worth the money. There isn't a single obvious answer. That's the kind of judgement I wanted students to practise when I redesigned this Stage 5 Year 9 Commerce unit.

I started with a SWOT appraisal of NESA's *The Business Environment*. I found a strong foundation: real business case studies, ethical questions, varied teaching approaches and a local-business investigation. But three design opportunities stood out: an optional recruitment role-play could prioritise performance over judgement; the site study could make students' inquiry more purposeful; and AI adoption, unlike some other digital issues, had no developed decision-making sequence. These are limitations I identified in the written plan, not claims about actual classroom results.

My first amendment, **Replacement**, keeps the existing recruitment teaching and case studies. What changes is the follow-up activity. Instead of writing a script about a hiring mistake, students sit on a recruitment panel. They assess three credible applicants against business criteria, explain a trade-off and then reconsider their decision when circumstances change. Assigned responsibilities and an individual recommendation make each student's reasoning assessable. The Week 11 module's combination of worked examples, collaboration and guided inquiry informed that sequence. My aim was not simply a livelier role-play, but a decision that students have to defend.

**Expansion** develops an existing strength: the local-business site study. It already includes observation, interviews, reporting and feedback, so removing it would make little sense. Students now begin with their own focused performance question. They separate what they observe from what the owner says, test evidence against another source and defend an improvement against an alternative. They then revise one claim after feedback. Dunn's 2025 course reading explains that inquiry builds on explicit teaching through questioning, evidence and reflection. The Education Endowment Foundation likewise emphasises planning for students to use feedback. This turns the original report into a more deliberate investigation, without creating a second assessment.

**Insertion** addresses a narrower gap in the current-issues content. The original mentions cybersecurity and influencer entrepreneurship, but does not develop AI adoption. Students advise whether a small business should adopt an AI tool, trial it with human oversight or defer. The Australian Bureau of Statistics reported that 12 per cent of businesses used AI in 2024–25. But an adoption rate is not evidence of improved performance. Students must weigh cost, customer trust and staff impacts, and identify what success would look like. That is a Commerce decision, not a technology demonstration.

These changes lead into my proposed assessment: a 600-to-750-word advisory brief to a hypothetical café owner. Students diagnose a performance problem, compare candidates and recommend a practical improvement within a fixed budget. A shared case pack makes evidence accessible without requiring an excursion or AI software. The selected Commerce outcomes assess explanation, decision-making, solutions and communication. As stressed in the Week 10 module, assessment needs alignment with what has actually been taught.

One thing I changed in my own thinking came from the Week 10 rubric workshop. Initially, I was drawn to activities that appeared engaging. Reviewing the criterion across all five bands pushed me to ask a harder question: what exactly will students think, justify and demonstrate? That's why I retained the original strengths, made the revisions traceable and checked that each change serves the learning rather than adding work for its own sake.

### How Step 3 develops Step 2

| A-band improvement (blue)                                                            | Lowest-band safeguard (red)                                                                  |
| ------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------- |
| Introduces a real business dilemma as a unifying opening.                            | Avoids spending the introduction reciting assignment instructions.                           |
| Builds a persuasive argument around decisions students must defend.                  | Avoids describing engagement as activity or performance alone.                               |
| Uses Dunn, EEF and ABS evidence to justify distinct teaching decisions.              | Avoids claiming research proves the interventions will succeed in this particular classroom. |
| Connects all three changes to a single assessment and learning purpose.              | Avoids adding disconnected activities or assessment requirements.                            |
| Concludes with a genuine reflection on how the design process changed your thinking. | Avoids declaring that the rubric guarantees an A grade.                                      |

The changes are cumulative: Step 3 develops the more precise explanations and research connections introduced in Step 2. It doesn't abandon that version and start again.

## The actual multimodal presentation plan

The website should not simply display a transcript while you read it. Its role is to show evidence, comparisons and revisions that your narration explains.

For the final script, I recommend this sequence:

| Approximate time | Website screen                       | What you explain                                                                |
| ---------------- | ------------------------------------ | ------------------------------------------------------------------------------- |
| 0:00–0:30        | Homepage and methodology             | Introduce the business decision-making problem and the redesign's purpose       |
| 0:30–1:00        | SWOT quadrants                       | Identify original strengths and the three opportunities for improvement         |
| 1:00–1:50        | 1) Replacement                       | Show the original recruitment activity, then reveal the hiring-panel simulation |
| 1:50–2:45        | 2) Expansion                         | Show the existing site study, then the strengthened inquiry and feedback cycle  |
| 2:45–3:30        | 3) Insertion                         | Show the current-issues content, then the AI investigation and ABS evidence     |
| 3:30–4:10        | Component 2 assessment proposal      | Explain the café advisory brief and its syllabus alignment                      |
| 4:10–4:45        | Rubric methodology / concluding view | Reflect on the decisions you made and the professional learning gained          |

I would use the revision selectors selectively rather than demonstrating every coloured sentence. The marker needs to understand why the teaching was improved, not watch every editing step.

For sources, show short citations on the appropriate screens rather than reading full reference details aloud. This will make the recorded narration feel more natural while keeping the academic evidence visible.

## Step 4 — Final review against the full presentation rubric

The A-band descriptor is:

Extended Abstract — A

“Delivers an engaging, polished, and persuasive presentation that critically justifies design decisions and demonstrates reflective professional practice.”

For the website, Step 4 should use the same centred, blurred-background review as Components 1 and 2. Each phrase appears with a check and a short explanation grounded in the final script.

### Phrase-by-phrase review

1\. Delivers

The script provides a complete presentation with a clear introduction, critical appraisal, three justified changes, assessment proposal and reflective conclusion, structured for a 4–5-minute recording.

2\. Engaging

The opening business dilemma establishes an immediate purpose. Interactive SWOT annotations, original-to-revised comparisons and realistic teaching scenarios give the audience evidence to examine alongside the narration.

3\. Polished

The planned sequence has a consistent visual style, logical transitions and an achievable speaking length. Its final polish will depend on recording quality, pacing, legibility and editing.

4\. Persuasive

The presentation advances one consistent argument: learning improves when students must make, test and justify decisions. Each amendment supplies a distinct example supporting that argument.

5\. Presentation

Spoken explanations are supported by the website's SWOT matrix, annotated NESA excerpts, staged revisions, research references and assessment proposal. The visual evidence adds meaning rather than duplicating a transcript.

6\. Critically

The appraisal acknowledges the original unit's strengths and existing provisions. It distinguishes limitations in the written design from actual classroom outcomes and evaluates what research can reasonably establish.

7\. Justifies

Each change is connected to an identified design issue and a pedagogical reason. The justification uses course materials, Dunn's inquiry research and external evidence concerning feedback and business technology.

8\. Design decisions

The presentation explains why recruitment is replaced, why the existing site study is expanded, and why AI adoption is inserted into the current-issues section. It also demonstrates their relationship to the proposed assessment.

9\. Demonstrates

The annotated comparisons make the design process observable, while the narration connects those visual modifications to the underlying decisions and their intended effects on learning.

10\. Reflective

The conclusion acknowledges a shift from selecting activities that appear engaging to asking what students will think, justify and demonstrate. This reflects learning from the Week 10 rubric workshop.

11\. Professional practice

The redesign preserves effective existing teaching, considers accessibility and workload, aligns learning with assessment, and uses evidence to support decisions without assuming future classroom success.

These checks justify how the planned presentation addresses the descriptor. They are not confirmation of an awarded A grade; delivery and polish can only be fully evaluated after the recording is complete.

### Whole-rubric check

| Band                  | Evaluation of the Step 3 design                                                                                                                                        |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| F — Prestructural     | The presentation has an identifiable structure and communicates the required key ideas.                                                                                |
| D — Unistructural     | It goes beyond basic information and uses multiple visual comparisons purposefully.                                                                                    |
| C — Multistructural   | The SWOT, three changes, research and assessment proposal are clearly communicated.                                                                                    |
| B — Relational        | The script synthesises the changes around a consistent argument with deliberate multimodal support.                                                                    |
| A — Extended Abstract | The design additionally provides critical justification, persuasive framing and reflection on professional learning; the final recording must realise these qualities. |

## Research used in the script

The following sources support the claims in our final script.

| Source                                 | Use in the presentation                                                                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------- |
| EDUC2060 Week 11 lecture materials     | Combining explicit teaching, worked examples, collaboration and inquiry for Replacement      |
| Dunn (2025), pp. 32–35                 | Structured inquiry, questioning, evidence interpretation and student ownership for Expansion |
| Education Endowment Foundation (2021)  | Planning opportunities for students to act on feedback for Expansion                         |
| Australian Bureau of Statistics (2026) | Contemporary evidence for the AI-adoption investigation                                      |
| EDUC2060 Week 10 lecture materials     | Alignment between curriculum, classroom learning, learners and assessment                    |
| NESA Commerce 7–10 (2024)              | Verification of the four selected syllabus outcomes                                          |

Dunn's article specifically explains that inquiry builds upon explicit teaching and involves questioning, evidence collection and interpretation.&#x20;

gtanswact.org.au



The EEF recommends planning for students to receive and use feedback, rather than treating feedback delivery as the end of the learning process.&#x20;

EEF



The ABS reported 12% business AI use in 2024–25. Its figures measure reported use, not proof of improved performance.&#x20;

Australian Bureau of Statistics



The four selected outcomes are confirmed in the official NESA syllabus.&#x20;

NSW Education Standards Authority



One research gap remains: Dunn (2025) is the course reading whose full text I've directly verified. The Week 10 and 11 materials are verified course modules, not additional course readings. Because your assignment requests reference to course readings in the plural, I recommend incorporating a second prescribed reading—ideally Barnes (2024) on assessment—once we can verify the relevant passage. I would not invent a finding from that chapter.

Also, if we use an ABS industry-specific figure for the assessment's café, we should use Accommodation and Food Services (5%), not Retail Trade (9%).&#x20;

Australian Bureau of Statistics



## Component 3 — Website implementation structure

When we add Component 3, it should contain:

1. Step 1 — Initial C-band script

   Full original script with the C descriptor and no revision highlighting.
2. Step 2 — B/D revisions

   The Step 2 script compared directly against Step 1, with green, yellow and grey highlighting on actual changed wording.
3. Step 3 — A/F refinements

   The Step 3 script compared directly against Step 2, with blue, red and grey highlighting on the cumulative revisions.
4. Step 4 — Final A-band review

   A centred review panel containing the exact rubric descriptor and eleven checked explanations above, with no extra Overall Judgement section.

The View Original Work greyscale system should remain untouched for now, and Component 1 and Component 2 should remain unchanged.

### Where we are

We now have all four stages of Component 3 developed, including three complete scripts, the rationale for the revisions, the multimodal recording sequence and the final rubric review.

My recommendation is to use the Step 3 script as the recording baseline, subject to verifying one further course reading and rehearsing the timing. It is more persuasive than the earlier drafts while remaining grounded in the actual NESA unit, our three amendments and the assessment proposal.