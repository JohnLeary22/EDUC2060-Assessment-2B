# VS Code Agent — Complete and Verify EDUC2060 Components 2 and 3

## Goal

In the **currently open** `EDUC2060-Assessment-2B-Presentation` website project, fully complete both Component 2 (Assessment Task Proposal) and Component 3 (Multimodal Presentation), while **preserving every part of Component 1** and the original-work viewing system. This is an implementation job: edit the existing website, not merely describe a plan or generate a second standalone project. Continue the existing work; do not discard the Component 2 changes already made.

### Read these reference files IN FULL before editing

1. `EDUC2060_Component2_Implementation_Content.json` — sole authoritative source for Component 2 prose, all five descriptor sentences and 11 Step 4 checks.
2. `EDUC2060_Component3_Implementation_Content.json` — authoritative structured source for full Component 3 scripts and review, extracted directly from the attached material.
3. `EDUC2060_Component3_Original_Source.md` — complete Component 3 handover and source context (use for audit, not as competing wording).

These files may be attached in chat or saved to the workspace. Find their actual locations; avoid creating duplicate runtime data files if canonical content already exists in `Steps/`. If a reference is inaccessible in VS Code, stop and report precisely which file is missing instead of inventing its contents. **Do not assume this prompt itself contains every script.**

## First: inspect the current state

- The screenshot showed **12 changed files** from a previous Component 2 implementation. Inspect existing changes and the current file tree, `js/app.js`, routing, data modules, CSS, `index.html`, `Steps/`, and existing Component 1 review modal **before editing**.
- Determine what Component 2 already implements and what remains incomplete. Preserve correct work. **No blind reset, revert, overwrite, duplication of views or wholesale rewrite.**
- If git is available, inspect status/diff and report it. If changes are uncommitted, preserve them.
- Use the same HTML/CSS/JavaScript module architecture and existing design language. No dependencies, frameworks, unrelated refactors, or second application.

## Website navigation

Homepage must show all THREE working destinations:
- **Three substantial changes to the Unit Plan** → existing Component 1 pages, behavior unchanged.
- **Proposed Assessment Task** → Component 2, enabled and clickable.
- **Multimodal Presentation** → Component 3, now ENABLED and clickable (override the previous Component-2-only handover instruction that said to leave it inactive).

Give Components 2 and 3 their own routes in the existing router, consistent page headings, clear back/home navigation, and Step 1 / Step 2 / Step 3 selectors plus a Step 4 review trigger. Browser back/forward and direct routes must work. Each component keeps its own selected step while opening/closing Step 4. Do not let their state leak between components. Do not change Component 1 routes (`#/swot`, `#/change/a1|b1|c1`) or View Original Work functionality.

## Component 2 — FULL implementation and audit

The existing Component 2 work must be **finished and verified**, not re-implemented unnecessarily.

- Step 1: show **the full exact** `stages.step1.body` (C-band original baseline), with the exact C descriptor. No revision highlights.
- Step 2: show **the full exact** `stages.step2.body`, referenced against B and D descriptors. Phrase-level changes versus **Step 1 only**: green for B, muted yellow for D, neutral grey for general changes. Don't colour unchanged text, whole paragraphs, or words merely because they appear in a modified paragraph.
- Step 3: show **the full exact** `stages.step3.body`, referenced against A and F descriptors. Phrase-level changes versus **Step 2 only**: blue for A, muted red for F, neutral grey for general changes. Do not compare with Step 1.
- Show the **exact official descriptor strings from the Component 2 JSON**; label A/B/C/D/F as achievement bands, not awarded university marks. Only include the bands appropriate to the selected version.
- Step 4: separate scrollable centred white modal with blurred backdrop, pale blue A descriptor, **all 11 exact `step4.items`** with check marks. No Overall Judgement and no claim of an awarded grade or measured outcomes. Close by button, Escape and outside backdrop; restore focus and scroll correctly.
- The task is an **individual** advisory brief; do not invent a student marking rubric.
- Preserve line breaks, headings, wording, section numbers, source references, length and all detailed requirements from the JSON. Avoid summary cards replacing the full bodies; optional supporting summaries are fine only when the entire text is accessible.

**Important conflict resolution:** the prior Component-2-only prompt contains a stale reference to an A-descriptor phrase (“critical and enlivened”) that does NOT appear in the supplied canonical JSON. Do not introduce that phrase or rewrite official descriptors based on that prompt. For Component 2, the JSON is authoritative.

## Component 3 — FULL implementation

Use the new Component 3 JSON's full content exactly (not an outline and not invented rewrites):

1. **Step 1 — Initial C-band script**: show every paragraph of `stages.step1.body`; no revision colours. Display Multistructural — C and source's brief rubric-focus summary (clearly not an official descriptor quote).
2. **Step 2 — B/D revisions**: show **every paragraph** of `stages.step2.body` with source's B/D rationale and compact colour key. Highlight only actual changed phrases compared with **Step 1**, using green (B), yellow (D), grey (other). Show the Relational — B and Unistructural — D bands.
3. **Step 3 — A/F refinements**: show **every paragraph** of `stages.step3.body`; highlight only the actual changes compared with **Step 2**, using blue (A), red (F), grey (other). Show the Extended Abstract — A and Prestructural — F bands. This is the provisional **recording script**, not a recording or an awarded mark.
4. **Step 4 — final A-band review**: isolated modal in the same visual interaction pattern as Components 1 and 2; show exact `step4.heading`, A descriptor verbatim and all **11 checked keyword/explanation pairs** once. End with close/return controls, without Overall Judgement or an appended award/grade. Be honest that delivery/polish cannot be fully assessed until recorded.

Within Component 3, also make the **full timed website/narration run-of-show** and the source's **research/references and caveats** accessible in clearly labelled, secondary sections (e.g. 'Recording plan' and 'Research notes'); don't clutter the main script. You may also present Step 2/3 rationale and the source whole-rubric design check in a separate supporting accordion outside Step 4, but do NOT turn the Step 4 review into an 'overall judgement'. Do not show a wall of script text as the homepage.

### Fidelity, rubrics, diffs

- The Component 3 source supplies a verbatim A-band descriptor. For B/C/D/F it has **working summaries only**, NOT exact official descriptor sentences. Display them clearly as 'Rubric focus (summary)' or display the band names alone; **do not invent or claim exact official wording**. The F band also lacks a source-supplied standalone summary; don't fabricate one.
- Preserve author-provided prose exactly: don't fix statistics, change pronouns, silently insert references, or invent pedagogy. Component 3's script claims are provisional academic drafts. Do not add a Barnes (2024) finding without verified material.
- Step 1 → Step 2 → Step 3 must preserve independent drafts, with **consecutive baselines** rather than cumulative comparison against Step 1 for all versions. If using a diff algorithm, assign colours only to defensible changed phrases in line with source `revisionRationale`; not all additions are 'higher band' by default. Do not colour unchanged words. Verify that collecting the rendered text (ignoring style spans) exactly matches the source strings as visible prose, including punctuation. Preserve italic/bold semantics encoded in Markdown.
- Any markdown-to-HTML rendering must be escaped/sanitised and must **not render raw `**`, `_`, `<span>` markup**, or expose cross-site-scripting vulnerabilities. The supplied paragraph data is content; never use untrusted code evaluation.
- Never replace the entire script with an overview, excerpts, or talking-point cards. The recording plan is an accessory; the three full versioned scripts are mandatory.

## Keep Components 1/2/3 independent

- Treat Component 1 as read-only, including original/revised excerpts, comments, exact passage text, reveal/collapse behavior, visual greyscale rules, routes and Step 4 modal.
- Treat already-correct Component 2 as preserved when adding Component 3. Separate Step 4 modal content and event listeners so no duplication or state contamination occurs.
- Global `View Original Work` toggle must retain its existing appearance and logic. Component 2/3 must not change it or accidentally become greyscaled; obey its existing component-specific rules rather than global new styles.
- Components 2 and 3 should feel native to the existing design (same typography, cards, muted colours, whitespace), with semantic buttons/links, visible keyboard focus and responsive layouts.

## Exact acceptance checks — do these, not merely claim success

1. Homepage: all three component buttons work; nothing points to a blank screen. Back-to-home works for both new sections.
2. Component 2: Step 1, 2, 3 each render **all source text** including headings and outcomes; toggle several times. Step 4 shows all 11 checks once and exact descriptor.
3. Component 3: Step 1, 2, 3 each render **all source scripts**, paragraph for paragraph. Step 4 shows 11 exact checks once and correct A descriptor. Recording plan and research notes accessible.
4. Component 2 Step 2 diff baseline exactly C2 Step 1; C2 Step 3 diff baseline exactly C2 Step 2. Component 3 Step 2 diff baseline exactly C3 Step 1; C3 Step 3 baseline exactly C3 Step 2. Correct green/yellow/grey and blue/red/grey legends. No unchanged text coloured as a revision.
5. For **each script/body version**, inspect rendered text in the browser (e.g. use DOM `textContent` appropriately normalised only for rendering whitespace) and compare it with canonical data after consistent Markdown rendering. Do not lose text at highlights or formatting boundaries.
6. Correct descriptors: C2 all five exact JSON sentences; C3 A exact JSON and other band summaries not falsely labelled as official. No numeric scores or award language.
7. All three Step 4 modals remain independent. Close by button / Escape / backdrop; restore focus, handle body scroll and keep active step. All modals usable on phone widths.
8. Revisit Component 1's SWOT, all three changes, source passages, old modal, links, comments, original-work mode, selector state, and keyboard interactions: **no regressions**.
9. Test desktop and 320, 375, 390px widths for overflow, clipping, overlapping buttons, unreadable text and scroll traps. Check JavaScript errors, console logs and syntax/editor errors. No new packages.
10. Document any known limitations, especially missing exact B/C/D/F Component 3 rubric descriptor wording and missing second prescribed reading. Don't invent academic content to hide them.

## Report when done

Return a concise summary of: (a) files changed, (b) exactly what was completed for each component, (c) which tests passed / failed / could not be run, (d) outstanding academic-source gaps. **Do not overwrite, revert or restructure unrelated files.**
