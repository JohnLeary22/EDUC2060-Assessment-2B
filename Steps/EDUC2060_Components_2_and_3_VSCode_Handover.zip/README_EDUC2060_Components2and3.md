# EDUC2060 Components 2 + 3 — VS Code handover

This bundle contains content and implementation instructions, NOT a completed website. The existing VS Code workspace is needed to apply the changes.

## Files

- `EDUC2060_Components2and3_VSCode_Agent_Prompt.md` — comprehensive VS Code agent instruction to finish/audit Component 2 and build Component 3.
- `EDUC2060_Component2_Implementation_Content.json` — existing complete Component 2 wording, untouched.
- `EDUC2060_Component3_Implementation_Content.json` — structured source data for Component 3's three full scripts, 11-item final review, recording plan and research notes.
- `EDUC2060_Component3_Original_Source.md` — original user-provided Component 3 draft for audit.

## To use

1. Extract the ZIP. Put the files somewhere the VS Code agent can access inside the current `EDUC2060-Assessment-2B-Presentation` project (preferably inside `Steps/` for the JSON and an `Instructions/` folder or project root for the prompt/source). If the existing Component 2 JSON is already there, compare before copying — do NOT create a competing or duplicate source.
2. In VS Code agent chat, attach or reference the agent prompt and both JSON files plus the original Component 3 source. Ask it to **read the prompt and all attached references in full, then implement them in the current open website**.
3. Inspect changed files and test the pages before clicking Keep/accepting a batch of changes.

## Academic accuracy note

The Component 3 source supplied the A descriptor verbatim, but not official word-for-word descriptors for B/C/D/F. The data and prompt avoid inventing those. A second prescribed reading also remains to be verified; the scripts are preserved exactly as supplied.
